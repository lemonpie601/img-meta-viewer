// 백그라운드 서비스 워커
// 콘텐츠 스크립트는 CORS 때문에 다른 도메인 이미지를 직접 받을 수 없어서
// 여기서 대신 받아 base64로 넘겨준다.

function toBase64(buf) {
  const bytes = new Uint8Array(buf);
  const CHUNK = 0x8000;
  let bin = '';
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
}

async function fetchImage({ url, range }) {
  const headers = { Accept: 'image/*,*/*' };
  if (range) headers.Range = range;
  // credentials: 'include' — 디시인사이드처럼 로그인·세션 쿠키에 따라
  // 다른 이미지를 내려주는 사이트가 있어서 브라우저와 같은 조건으로 요청한다.
  const res = await fetch(url, { headers, credentials: 'include', cache: 'default' });
  const buf = await res.arrayBuffer();
  return {
    ok: res.status >= 200 && res.status < 300,
    status: res.status,
    contentRange: res.headers.get('content-range') || '',
    contentType: res.headers.get('content-type') || '',
    data: toBase64(buf),
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'imv-fetch') {
    fetchImage(msg)
      .then(sendResponse)
      .catch((e) => sendResponse({ ok: false, status: 0, error: String(e && e.message || e) }));
    return true;   // 비동기 응답
  }
  if (msg && msg.type === 'imv-download') {
    chrome.downloads.download({ url: msg.url, filename: msg.filename })
      .then(() => sendResponse({ ok: true }))
      .catch((e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true;
  }
  return false;
});
