const DEFAULTS = { openOn: 'alt', skipStickers: true };

function paint(cfg) {
  for (const el of document.querySelectorAll('input[name="openOn"]')) {
    el.checked = el.value === cfg.openOn;
    el.closest('.opt').classList.toggle('on', el.checked);
  }
  document.getElementById('skipStickers').checked = !!cfg.skipStickers;
}

chrome.storage.local.get(DEFAULTS).then((cfg) => {
  paint(Object.assign({}, DEFAULTS, cfg));
});

for (const el of document.querySelectorAll('input[name="openOn"]')) {
  el.addEventListener('change', () => {
    chrome.storage.local.set({ openOn: el.value });
    paint({ openOn: el.value, skipStickers: document.getElementById('skipStickers').checked });
  });
}

document.getElementById('skipStickers').addEventListener('change', (e) => {
  chrome.storage.local.set({ skipStickers: e.target.checked });
});
